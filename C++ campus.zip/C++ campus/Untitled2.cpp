#include <iostream>

using namespace std;
    int main()
    {
        int sisi;
        cout<<"Masukan Sisi :";
        cin>> sisi;


    }
