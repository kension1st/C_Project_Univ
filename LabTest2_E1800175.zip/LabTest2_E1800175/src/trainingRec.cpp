#include "trainingRec.h"

trainingRec::trainingRec()
{
    //ctor
}

trainingRec::~trainingRec()
{
    //dtor
}
