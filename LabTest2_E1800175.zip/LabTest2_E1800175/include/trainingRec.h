#ifndef TRAININGREC_H
#define TRAININGREC_H


class trainingRec
{
    public:
        trainingRec();
        virtual ~trainingRec();

    protected:

    private:
};

#endif // TRAININGREC_H
